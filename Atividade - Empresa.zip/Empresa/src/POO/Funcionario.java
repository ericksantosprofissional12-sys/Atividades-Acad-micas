package POO;

public abstract class Funcionario {
	private String nome;
	private double salarioBase;
	
	public Funcionario(String nome, double salarioBase) {
		this.nome = nome;
		this.salarioBase = salarioBase;
	}
	public abstract double calcularSalario(double salarioBase);
	
	public void exibirDados() {
		System.out.println("Funcionario: "+ this.nome +"\nSalário Base: "+ calcularSalario(salarioBase));
	}
	
	public String getNome() {
		return this.nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public double getSalarioBase() {
		return this.salarioBase;
	}
	public void setSalarioBase(double salarioBase) {
		this.salarioBase = salarioBase;
	}
}
