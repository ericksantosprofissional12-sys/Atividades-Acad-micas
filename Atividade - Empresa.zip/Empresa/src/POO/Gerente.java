package POO;

public class Gerente extends Funcionario implements Verificacao {
	private String senhaObr = "20051201";
	
	public Gerente(String nome, double salarioBase) {
		super(nome, salarioBase);
		
	}
	
	@Override
	public double calcularSalario(double salarioBase) {
		return (salarioBase + (salarioBase * 0.2));
	}
	@Override
	public boolean verificar(String senha) {
		if(this.senhaObr == senha) {
			System.out.println("Acesso permitido!");
			return true;
		}else {
			System.out.println("Acesso negado!");
			return false;
		}
	}
	
}
