package POO;

interface Verificacao {
	boolean verificar(String senha);
}
