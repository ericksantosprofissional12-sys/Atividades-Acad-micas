package POO;

import java.util.ArrayList;

public class Empresa {
	
	ArrayList<Funcionario> funcionario = new ArrayList<Funcionario>();
	
	public void addFuncionarios(Funcionario fc) {
		this.funcionario.add(fc);
	}
	
	public void removeFuncionarios(String nome) {
		int contagem = 0;
		for(int i = 0; i < funcionario.size(); i++) {
			if(funcionario.get(i).getNome().equalsIgnoreCase(nome)) {
				funcionario.remove(i);
				contagem++;
			}
		}
		if(contagem == 0) {
			System.out.println("Funcionario não reconhecido!");
		}else {
			System.out.println("Funcionario deletado com sucesso!");
		}
	}
	public void exibirFuncionarios() {
		for(int i = 0; i < funcionario.size(); i++) {
			System.out.println("Funcionario: "+(funcionario.get(i).getNome())+"\nSalario: R$ "+funcionario.get(i).calcularSalario(funcionario.get(i).getSalarioBase()));
		}
	}
}
