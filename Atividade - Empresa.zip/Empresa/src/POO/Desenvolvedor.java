package POO;

public class Desenvolvedor extends Funcionario {
	
	public Desenvolvedor(String nome, double salarioBase) {
		super(nome, salarioBase);
		getNome();
		getSalarioBase();
	}
	@Override
	public double calcularSalario(double salarioBase) {
		return (salarioBase + (salarioBase * 0.1));
	}
}
