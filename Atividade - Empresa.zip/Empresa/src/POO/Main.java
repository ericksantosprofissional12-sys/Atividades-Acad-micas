package POO;

public class Main {

	public static void main(String[] args) {
		
		Empresa empre1 = new Empresa();
		Gerente gen1 = new Gerente("Rafael", 5000);
		Desenvolvedor dev1 = new Desenvolvedor("Erick", 2500);
		
		
		empre1.addFuncionarios(dev1);
		empre1.addFuncionarios(gen1);
		
		empre1.exibirFuncionarios();
		
		gen1.verificar("20051201");
		
		empre1.removeFuncionarios("Erick");
		
		empre1.exibirFuncionarios();
	}

}
