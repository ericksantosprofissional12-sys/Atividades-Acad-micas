package Lista1;

import java.util.ArrayList;

public class Lista {
	public static void main(String[] args) {
		
		ArrayList<Object> Lista = new ArrayList<Object>();
		
		Lista.add("Olá");
		Lista.add("Tudo");
		Lista.add("Bem");
		Lista.add("Como");
		Lista.add("Vai");
		Lista.add("Você?");
		Lista.add("Acredito");
		Lista.add("Que");
		Lista.add("Bem");
		Lista.add("É isso");
		Lista.add("Tchau");
		
		for(int i = 0; i < Lista.size(); i++) {
			System.out.println(Lista.get(i));
		}
		for(int i = Lista.size() - 1; i > 0; i-- ) {
			System.out.println(Lista.get(i));
		}
	}
}
