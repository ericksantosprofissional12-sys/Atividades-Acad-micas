package carro;

public class carro {
	 public String cor;
	 public String modelo;
	 public double velocidadeAtual;
	 public double velocidadeMaxima;
	 public boolean ligado;

	    public carro(String cor, String modelo, double velocidadeMaxima) {
	        this.cor = cor;
	        this.modelo = modelo;
	        this.velocidadeMaxima = 180;
	        this.velocidadeAtual = 0;
	        this.ligado = false;
	    }

	    public void ligar() {
	        ligado = true;
	        System.out.println("Carro ligado!");
	    }

	    public void desligar() {
	        ligado = false;
	        System.out.println("Carro Desligado!");
	    }

	    public void acelerar(int velocidade) {
	        if(ligado) {
	        	if (velocidade > velocidadeMaxima) {
	        		System.out.println("Velocidade não permitida!\nVelocidade máxima é " + this.velocidadeMaxima);
	        	} else {
	        		this.velocidadeAtual += velocidade;
	        	}
			}else {
				System.out.println("De a partida no carro primeiro!");
			}
	        	
	    }

	    public int passarMarcha() {
	        if (velocidadeAtual >= 0 && velocidadeAtual <= 20) {
	        return 1;
	     }else if(velocidadeAtual >= 21 && velocidadeAtual <= 40){
	        return 2;
	    }else if(velocidadeAtual >= 41 && velocidadeAtual <= 70){
	        return 3;
	    }else if(velocidadeAtual >= 71 && velocidadeAtual <= 100){
	        return 4;
	    }else if(velocidadeAtual >= 101){
	        return 5;
	    }else{
	        return 0;
	        }
	    }
	    
		public String toString() {
			return "Carro [cor=" + cor + ", modelo=" + modelo + ", velocidadeAtual=" + velocidadeAtual
					+ ", velocidadeMaxima=" + velocidadeMaxima + ", ligado=" + ligado + "]";
		}
}
