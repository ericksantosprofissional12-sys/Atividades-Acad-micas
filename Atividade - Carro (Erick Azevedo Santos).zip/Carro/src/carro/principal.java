package carro;

public class principal {
	public static void main(String[] args) {
        
        carro carro1 = new carro("Azul", "Corsa", 180);
        carro carro2 = new carro("preto", "mustang", 180);
        
        System.out.println(carro1);
        carro1.ligar();
        carro1.acelerar(200);
        System.out.println(carro2);
    }
}
