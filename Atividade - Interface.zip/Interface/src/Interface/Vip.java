package Interface;

public class Vip extends Ingresso implements IIngresso{
	private double adicao;
	public Vip(int numero, String tipo, double valor) {
		super(numero, tipo, valor);
		
	}

	@Override
	public String ImprimirValor() {
		adicao = valor + (valor * 0.15);
		return "Ingresso Vip: "+ adicao;
	}

	@Override
	public String toString() {
		return "Cliente Vip \nNumero do Ingresso: " + numero + "\nTipo do Ingresso: " + tipo;
	}
	
}
