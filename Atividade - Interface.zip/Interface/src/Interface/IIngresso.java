package Interface;

interface IIngresso {
	String ImprimirValor();
}
