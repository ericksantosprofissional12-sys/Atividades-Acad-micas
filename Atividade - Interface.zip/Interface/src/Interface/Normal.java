package Interface;

public class Normal extends Ingresso implements IIngresso{
	
	public Normal(int numero, String tipo, double valor) {
		super(numero, tipo, valor);
		
	}

	@Override
	public String ImprimirValor() {
		return "Ingresso normal: " + this.valor;
	}

	@Override
	public String toString() {
		return "Ingresso Normal: "+ numero +"\nTipo do Ingresso: " + tipo;
	}
	
}
