package Interface;

public class Ingresso implements IIngresso{
	protected int numero;
	protected String tipo;
	protected double valor;
	
	public Ingresso(int numero, String tipo, double valor) {
		this.numero = numero;
		this.tipo = tipo;
		this.valor = valor;
	}
	
	
	public String ImprimirValor() {
		return "Valor do Ingresso: " + valor;
	}

	@Override
	public String toString() {
		return "Ingresso [numero=" + numero + ", tipo=" + tipo + "]";
	}

}
