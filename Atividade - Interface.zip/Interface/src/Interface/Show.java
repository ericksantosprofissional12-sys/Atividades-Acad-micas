package Interface;

public class Show {

	public static void main(String[] args) {
		//=====================================|
				Normal i1 = new Normal(150,"NORMAL", 1); 
				Vip i2 = new Vip(350, "VIP", 2); 
				CamaroteSuperior i3 = new CamaroteSuperior(1000, "CAMAROTE", 3); 
		
				System.out.println (i1.toString()); 
				System.out.println (i1.ImprimirValor()); 
				
				System.out.println("\n");
				System.out.println (i2.toString()); 
				System.out.println (i2.ImprimirValor());
				
				System.out.println("\n");
				System.out.println (i3.toString()); 
				System.out.println (i3.ImprimirValor());
		
	}

}
