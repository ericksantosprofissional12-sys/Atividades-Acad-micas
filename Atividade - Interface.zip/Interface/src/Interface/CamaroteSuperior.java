package Interface;

public class CamaroteSuperior extends Ingresso implements IIngresso {
	private double adicao;
	public CamaroteSuperior(int numero, String tipo, double valor) {
		super(numero, tipo, valor);
		
	}

	@Override
	public String ImprimirValor() {
		adicao = adicao + (adicao * 0.30);
		return "Ingresso do Camarote: " + adicao;
	}
	@Override
	public String toString() {
		return "Ingresso do Camarote: "+ numero +"\nTipo do Ingresso: " + tipo;
	}
}
