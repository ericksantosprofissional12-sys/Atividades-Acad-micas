package Futebol;

import java.util.List;
import java.util.ArrayList;

public class Time {
	private String nome;
	private String nomeTecnico;
	private ArrayList<Jogador> jogadores = new ArrayList<Jogador>();
	private ArrayList<Jogador> jogadoresEscalados = new ArrayList<Jogador>();
	
	public Time(String nome, String nomeTecnico) {
		super();
		this.nome = nome;
		this.nomeTecnico = nomeTecnico;
	}
	public void contratarJogador(String nome, Integer numeroCamisa) {
		Jogador jogador = new Jogador(nome, numeroCamisa);
		jogadores.add(jogador);
	}
	private Jogador encontreJogador(String nomeJogador) {
		for(Jogador jog : jogadores) {
			if(jog.getNome().equalsIgnoreCase(nomeJogador)) {
				return jog;
			}
		}
		return null;
	}
	private Integer calculoQtdJogadores(SitEscalacaoEnum SitEnum) {
		Integer Qtd = 0;
		for(Jogador jogador : jogadores) {
			if(SitEnum.equals(jogador.getSitEnum())) {
				Qtd++;
			}
		}
		return Qtd;
	}
	
	public boolean escalarJogador(String nomeJogador, SitEscalacaoEnum SitEnum) {
		Jogador jogador = encontreJogador(nomeJogador);
		if(jogador == null) {
			return false;
		}
		if(jogador.getSitEnum() != null) {
			return false;
		}
		if(calculoQtdJogadores(SitEnum) >= SitEnum.getQtdMaxima()) {
			return false;
		}
		jogador.setSitEscalacaoEnum(SitEnum);
		jogadoresEscalados.add(jogador);
		return true;
	}
	
	public void removerJogadorEscalacao(String nome) {
		Jogador jogador = encontreJogador(nome);
		if(jogador != null) {
			jogador.setSitEscalacaoEnum(null);
			jogadoresEscalados.remove(jogador);
		}
	}
	
	public List<Jogador> obterEscalacao(){
		return jogadoresEscalados;
	}
	
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public String getNomeTecnico() {
		return nomeTecnico;
	}
	public void setNomeTecnico(String nomeTecnico) {
		this.nomeTecnico = nomeTecnico;
	}
	
	@Override
	public String toString() {
		return "Time [nome=" + nome + ", nomeTecnico=" + nomeTecnico + ", jogadores=" + jogadores
				+ ", jogadoresEscalados=" + jogadoresEscalados + "]";
	}
	
	
}
