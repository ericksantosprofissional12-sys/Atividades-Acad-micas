package Futebol;


public class Jogo {
		
	private static String nome[] = {"Hildo","Caue","Marcus Vinicius","Murilo","Talisson"};
	
	public static void main(String[] args) {
		Time team = new Time("Vitoria", "Fábio Mota");
		
		contratar5Jogadores(team);
		escalar3Titulares(team);
		escalar2Reservas(team);
		listarJogadoresEscalados(team);
	}
	
	private static void contratar5Jogadores(Time team) {
		for(Integer i= 0; i < nome.length; i++) {
				team.contratarJogador(nome[i], i+1);
		}
	}
	private static void escalar3Titulares(Time team) {
		for(Integer i= 0; i < 3; i++) {
			team.escalarJogador(nome[i], SitEscalacaoEnum.TITULAR);
		}
	}
	private static void escalar2Reservas(Time team) {
		for(Integer i = 3; i < 5; i++) {
			team.escalarJogador(nome[i], SitEscalacaoEnum.RESERVA);
		}
	}
	private static void listarJogadoresEscalados(Time team) {
		System.out.println("==== Jogadores Escalados ====");
		for (Jogador jog : team.obterEscalacao()) {
			System.out.println(jog);
	}
}
}
