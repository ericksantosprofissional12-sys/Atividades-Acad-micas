package Futebol;

public class Jogador {
	
	private String nome;
	private Integer numeroCamisa;
	private SitEscalacaoEnum SitEnum;
	
	public Jogador(String nome, Integer numeroCamisa) {
		super();
		this.nome = nome;
		this.numeroCamisa = numeroCamisa;
		this.SitEnum = null;
	}
	
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	
	public Integer getNumeroCamisa() {
		return numeroCamisa;
	}
	public void setNumeroCamisa(Integer numeroCamisa) {
		this.numeroCamisa =  numeroCamisa;
	}
	public SitEscalacaoEnum getSitEnum() {
		return SitEnum;
	}
	public void setSitEscalacaoEnum(SitEscalacaoEnum SitEnum) {
		this.SitEnum = SitEnum;
	}

	@Override
	public String toString() {
		return "Jogador [nome=" + nome + ", numeroCamisa=" + numeroCamisa + ", SitEnum=" + SitEnum + "]";
	}
}
