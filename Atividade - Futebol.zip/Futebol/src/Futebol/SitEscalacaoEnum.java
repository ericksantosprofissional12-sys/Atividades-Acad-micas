package Futebol;

public enum SitEscalacaoEnum {
	
	TITULAR(11), RESERVA(12);
	
	private Integer QtdMaxima;
	
	private SitEscalacaoEnum(Integer QtdMaxima) {
		this.QtdMaxima = QtdMaxima;
	}
	public Integer getQtdMaxima() {
		return QtdMaxima;
	}
}
